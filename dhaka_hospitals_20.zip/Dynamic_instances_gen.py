import pandas as pd
import os
import random
import time

def generate_hospital_instances(input_file, output_dir, sizes):
    """
    Generate random subsets of hospital locations from the main file.
    Each run produces different random samples.

    Parameters:
        input_file (str): Path to the main CSV file.
        output_dir (str): Folder to save the generated files.
        sizes (list): List of subset sizes (e.g., [120, 100, 80, 60]).
    """
    # Load main dataset
    data = pd.read_csv(input_file)
    print(f"Loaded {len(data)} hospital records from {input_file}")

    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Use a different random seed each time
    random_seed = int(time.time())
    random.seed(random_seed)
    print(f" Using random seed: {random_seed}")

    # Generate subsets
    for size in sizes:
        if size > len(data):
            print(f"⚠️ Skipping size {size}: not enough records in dataset.")
            continue

        subset = data.sample(n=size, random_state=random.randint(1, 1_000_000))
        output_file = os.path.join(output_dir, f"dhaka_{size}_hospitals.csv")
        subset.to_csv(output_file, index=False)
        print(f" Created: {output_file} ({size} hospitals)")

    print("\n All random subsets generated successfully!")

# Example usage
if __name__ == "__main__":
    input_csv = "dhaka_random_locations.csv"   # main dataset
    output_folder = "generated_instances"      # folder for output
    instance_sizes = [120, 100, 80, 60]        # desired subset sizes

    generate_hospital_instances(input_csv, output_folder, instance_sizes)
